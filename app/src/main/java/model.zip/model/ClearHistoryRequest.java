package model;

public class ClearHistoryRequest {
    private String userId;

    public ClearHistoryRequest(String userId) {
        this.userId = userId;
    }
}
