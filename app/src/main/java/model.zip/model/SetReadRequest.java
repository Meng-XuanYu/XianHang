package model;

public class SetReadRequest {
    private String userId;

    public SetReadRequest(String userId) {
        this.userId = userId;
    }
}
