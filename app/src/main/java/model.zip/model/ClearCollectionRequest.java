package model;

public class ClearCollectionRequest {
    private String userId;

    public ClearCollectionRequest(String userId) {
        this.userId = userId;
    }
}
