package model;

public class AISearchRequest {
    private String content;

    public AISearchRequest(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }
}
