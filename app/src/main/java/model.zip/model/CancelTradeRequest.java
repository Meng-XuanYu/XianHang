package model;

public class CancelTradeRequest {
    private String tradeId;

    public CancelTradeRequest(String tradeId) {
        this.tradeId = tradeId;
    }
}
