package model;

public class GetMoneyResponse {
    private String status;
    private String message;
    private Double money;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public Double getMoney() {
        return money;
    }
}
