package model;

public class BuyCommodityResponse {
    private String status;
    private String message;
    private String tradeId;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getTradeId() {
        return tradeId;
    }
}
