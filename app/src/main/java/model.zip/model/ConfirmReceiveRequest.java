package model;

public class ConfirmReceiveRequest {
    private String tradeId;

    public ConfirmReceiveRequest(String tradeId) {
        this.tradeId = tradeId;
    }
}
