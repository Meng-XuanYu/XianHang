package model;

public class GetAttractivenessResponse {
    private String status;
    private String message;
    private int attractiveness;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public int getAttractiveness() {
        return attractiveness;
    }
}
