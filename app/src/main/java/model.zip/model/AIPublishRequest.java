package model;

public class AIPublishRequest {
    private String imageUrl;

    public AIPublishRequest(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
