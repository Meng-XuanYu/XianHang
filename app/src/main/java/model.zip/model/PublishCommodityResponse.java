package model;

public class PublishCommodityResponse {
    private String status;
    private String message;
    private String commodityId;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getCommodityId() {
        return commodityId;
    }
}
