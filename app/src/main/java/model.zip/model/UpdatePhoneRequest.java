package model;

public class UpdatePhoneRequest {
    private String userId;
    private String phone;

    public UpdatePhoneRequest(String userId, String phone) {
        this.userId = userId;
        this.phone = phone;
    }

    // Getters 和 Setters（如果需要）
}
