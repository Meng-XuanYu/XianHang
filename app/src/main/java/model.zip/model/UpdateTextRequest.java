package model;

public class UpdateTextRequest {
    private String userId;
    private String text;

    public UpdateTextRequest(String userId, String text) {
        this.userId = userId;
        this.text = text;
    }

    // Getters 和 Setters（如果需要）
}
