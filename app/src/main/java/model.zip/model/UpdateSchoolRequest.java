package model;

public class UpdateSchoolRequest {
    private String userId;
    private String school;

    public UpdateSchoolRequest(String userId, String school) {
        this.userId = userId;
        this.school = school;
    }

    // Getters 和 Setters（如果需要）
}
