package model;

public class UpdateNameRequest {
    private String userId;
    private String name;

    public UpdateNameRequest(String userId, String name) {
        this.userId = userId;
        this.name = name;
    }

    // Getters 和 Setters（如果需要）
}
