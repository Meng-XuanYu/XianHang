package model;

public class ConfirmSendRequest {
    private String tradeId;

    public ConfirmSendRequest(String tradeId) {
        this.tradeId = tradeId;
    }
}
