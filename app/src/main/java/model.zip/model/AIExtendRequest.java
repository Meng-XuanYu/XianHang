package model;

public class AIExtendRequest {
    private String content;

    public AIExtendRequest(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }
}
